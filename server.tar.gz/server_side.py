import json
import socket
import threading
import sys

def load_dictionary():
    try:
        with open("dictionary.json", "r") as file:
            return json.load(file)
    except FileNotFoundError:
        return {}
    
def save_dictionary(dictionary):
    with open("dictionary.json", "w") as file:
        json.dump(dictionary, file, indent=4)
    
lib = load_dictionary()


def handle_client(client_socket):
    while True:
        data = client_socket.recv(1024).decode().strip()
        if not data:
            break
        else:
            command, word = data.split(maxsplit = 1)

            if command == "define":
                defi = lib.get(word,"Word Not Found")
                client_socket.send(defi.encode())
            
            elif command == "add":
                new_word, new_definition = word.split(":", maxsplit=1)
                wordCheck = lib.get(new_word)

                if wordCheck:
                    client_socket.send("Word Already exist".encode())
                else:
                    lib[new_word.strip()] = new_definition.strip()
                    save_dictionary(lib)
                    client_socket.send("Word added to dictionary.".encode())

            else:
                client_socket.send("Invalid command.".encode())
            

        

    
    
def server_start(portNum):
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)


    try:
        server_socket.bind(('0.0.0.0', portNum))

        # Max value for request is 5 and low is 1 I used 2
        server_socket.listen(2)

        try: 
            while True:
                client_socket, _ = server_socket.accept()
                client_thread = threading.Thread(target=handle_client, args=(client_socket,))
                client_thread.start()

    
        except KeyboardInterrupt:
            print('Server Down')

        finally:
            server_socket.close()

    except socket.error as msg:
        print('Bind failed. Error Code : '
          + str(msg[0]) + ' Message '
          + msg[1])
        sys.exit()
    


if __name__ == "__main__":
    port_num = int(sys.argv[1])
    server_start(port_num)

